import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import getImageUrl from "../../utils/imageGetter";

function Login() {
  useEffect(() => {
    document.title = "Login";
  });

  const [isPassShown, setIsPassShown] = useState(false);
  const showPassHandler = () => {
    setIsPassShown((state) => !state);
  };

  return (
    <>
      <main className="flex flex-col justify-center items-center h-screen w-screen bg-sky-50">
        <section className="font-plusJakartaSans w-full h-full px-5 flex flex-col justify-center gap-y-1 lg:w-3/5 xl:w-3/6 md:py-20 md:px-24">
          <header className="mb-6 flex justify-center">
            <img
              src={getImageUrl("logo", "png")}
              alt="logo"
              className="w-1/3"
            />
            {/* <h1 className="text-lg font-semibold md:text-2xl">Login</h1> */}
          </header>
          <form className="flex flex-col gap-y-5">
            <div className="flex flex-col gap-y-3 relative">
              <label
                htmlFor="email"
                className="text-sm md:text-base font-semibold text-[#0B132A] lg:text-base"
              >
                Email
              </label>
              <input
                type="email"
                id="email"
                placeholder="Enter Your Email"
                className={`py-3.5 px-10 border rounded-lg border-[#DEDEDE] text-xs tracking-wide outline-none focus:border-primary`}
              />
            </div>
            <div className="flex flex-col gap-y-3 relative">
              <label
                htmlFor="password"
                className="text-sm md:text-base font-semibold text-[#0B132A] lg:text-base"
              >
                Password
              </label>
              <input
                type={isPassShown ? "text" : "password"}
                id="password"
                placeholder="Enter Your Password"
                className={`py-3.5 px-10 border rounded-lg border-[#DEDEDE] text-xs tracking-wide outline-none focus:border-primary`}
              />
              <div className="icon-password absolute top-[46px] left-4 md:top-[50px]">
                <img
                  src={getImageUrl("Password", "svg")}
                  alt="Password"
                  className="w-full h-full"
                />
              </div>
              <div
                className={`absolute top-[46px] right-4 md:top-[50px] ${
                  isPassShown ? " hidden" : "block"
                }`}
                id="btnHiddenPassword"
                onClick={showPassHandler}
              >
                <img
                  src={getImageUrl("EyeSlash", "svg")}
                  alt="EyeSlash"
                  className="w-full h-full"
                />
              </div>
              <div
                className={`absolute top-[45px] right-[15px] md:top-[49px] ${
                  isPassShown ? " block" : " hidden"
                }`}
                id="btn-show-password"
                onClick={showPassHandler}
              >
                <img
                  src={getImageUrl("eye", "svg")}
                  alt="eye"
                  className="w-[18px] h-[18px]"
                />
              </div>
            </div>
            <button
              type="submit"
              className="text-base font-medium text-[#0B132A] bg-sky-500 p-2.5 rounded-md hover:bg-sky-600 active:ring ring-sky-800"
            >
              Login
            </button>
          </form>
        </section>
      </main>
    </>
  );
}

export default Login;
